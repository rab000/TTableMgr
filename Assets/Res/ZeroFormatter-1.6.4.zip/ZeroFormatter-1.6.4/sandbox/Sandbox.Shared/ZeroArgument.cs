﻿
using ZeroFormatter;

namespace Sandbox.Shared
{
    [ZeroFormattable]
    public class ZeroClass
    {

    }

    [ZeroFormattable]
    public struct ZeroStruct
    {

    }
}
