﻿using System.Text;

namespace ZeroFormatter.Internal
{
    internal static class StringEncoding
    {
        public static Encoding UTF8 = new UTF8Encoding(false);
    }
}
